package com.fren_gor.ultimateAdvancementAPI;

import com.fren_gor.eventManagerAPI.EventManager;
import com.fren_gor.ultimateAdvancementAPI.advancement.Advancement;
import com.fren_gor.ultimateAdvancementAPI.advancement.BaseAdvancement;
import com.fren_gor.ultimateAdvancementAPI.advancement.RootAdvancement;
import com.fren_gor.ultimateAdvancementAPI.database.DatabaseManager;
import com.fren_gor.ultimateAdvancementAPI.database.TeamProgression;
import com.fren_gor.ultimateAdvancementAPI.events.PlayerLoadingCompletedEvent;
import com.fren_gor.ultimateAdvancementAPI.events.advancement.AdvancementDisposeEvent;
import com.fren_gor.ultimateAdvancementAPI.events.advancement.AdvancementDisposedEvent;
import com.fren_gor.ultimateAdvancementAPI.events.advancement.AdvancementRegistrationEvent;
import com.fren_gor.ultimateAdvancementAPI.exceptions.DisposedException;
import com.fren_gor.ultimateAdvancementAPI.exceptions.DuplicatedException;
import com.fren_gor.ultimateAdvancementAPI.exceptions.InvalidAdvancementException;
import com.fren_gor.ultimateAdvancementAPI.exceptions.UserNotLoadedException;
import com.fren_gor.ultimateAdvancementAPI.nms.wrappers.MinecraftKeyWrapper;
import com.fren_gor.ultimateAdvancementAPI.nms.wrappers.advancement.AdvancementWrapper;
import com.fren_gor.ultimateAdvancementAPI.nms.wrappers.packets.ISendable;
import com.fren_gor.ultimateAdvancementAPI.nms.wrappers.packets.PacketPlayOutAdvancementsWrapper;
import com.fren_gor.ultimateAdvancementAPI.util.AdvancementKey;
import com.fren_gor.ultimateAdvancementAPI.util.AdvancementUtils;
import com.fren_gor.ultimateAdvancementAPI.util.LazyValue;
import com.google.common.base.Preconditions;
import com.google.common.collect.Sets;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;
import com.fren_gor.ultimateAdvancementAPI.util.SchedulerSupport;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.Unmodifiable;
import org.jetbrains.annotations.UnmodifiableView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;

import static com.fren_gor.ultimateAdvancementAPI.util.AdvancementKey.checkNamespace;
import static com.fren_gor.ultimateAdvancementAPI.util.AdvancementUtils.validateTeamProgression;

/**
 * The {@code AdvancementTab} class represents a tab in the advancement GUI.
 * <p>Every advancement tab is represented by a unique namespace (not visible in the advancement GUI) and has only one {@link RootAdvancement}.
 * <p>An instance can be obtained using {@link UltimateAdvancementAPI#createAdvancementTab(String)}.
 * The returned instance is not initialised, that is it doesn't contain any advancement yet.
 */
public final class AdvancementTab {

    private final Plugin owningPlugin;
    private final EventManager eventManager;
    private final String namespace;
    private final DatabaseManager databaseManager;
    private final Map<AdvancementKey, Advancement> advancements = new ConcurrentHashMap<>();
    private final Map<Player, ClientState> players = new ConcurrentHashMap<>();
    private final AtomicLong clientGeneration = new AtomicLong();
    private final AdvsUpdateRunnable updateManager;

    private RootAdvancement rootAdvancement;
    private volatile boolean initialised = false, disposed = false, automaticallyShown = false, automaticallyGrant = false;
    @LazyValue
    private Collection<String> advNamespacedKeys;
    @LazyValue
    private Collection<BaseAdvancement> advsWithoutRoot;

    AdvancementTab(@NotNull Plugin owningPlugin, @NotNull DatabaseManager databaseManager, @NotNull String namespace) {
        checkNamespace(namespace);
        this.namespace = Objects.requireNonNull(namespace);
        this.owningPlugin = Objects.requireNonNull(owningPlugin);
        this.eventManager = new EventManager(owningPlugin);
        this.databaseManager = Objects.requireNonNull(databaseManager);
        this.updateManager = new AdvsUpdateRunnable();
        eventManager.register(this, PlayerQuitEvent.class, e -> { players.remove(e.getPlayer()); updateManager.pendingPlayers.remove(e.getPlayer()); updateManager.previousKeys.remove(e.getPlayer().getUniqueId()); });
    }

    /**
     * Returns whether the tab is initialised and not disposed.
     *
     * @return Whether the tab is initialised and not disposed.
     */
    public boolean isActive() {
        return initialised && !disposed;
    }

    /**
     * Returns the root advancement of this tab.
     *
     * @return The root advancement of this tab.
     * @throws IllegalStateException If the tab is not initialised.
     * @throws DisposedException If the tab is disposed.
     */
    @NotNull
    @Contract(pure = true)
    public RootAdvancement getRootAdvancement() {
        checkInitialisation();
        return rootAdvancement;
    }

    /**
     * Gets an unmodifiable {@link Collection} of all the tab's advancements.
     *
     * @return An unmodifiable {@link Collection} of all the tab's advancements.
     * @throws IllegalStateException If the tab is not initialised.
     * @throws DisposedException If the tab is disposed.
     */
    @UnmodifiableView
    @NotNull
    @Contract(pure = true)
    public Collection<@NotNull Advancement> getAdvancements() {
        checkInitialisation();
        return Collections.unmodifiableCollection(advancements.values());
    }

    /**
     * Gets an unmodifiable {@link Collection} of all the tab's advancements but the root.
     *
     * @return An unmodifiable {@link Collection} of all the tab's advancements but the root.
     * @throws IllegalStateException If the tab is not initialised.
     * @throws DisposedException If the tab is disposed.
     */
    @Unmodifiable
    @NotNull
    public Collection<@NotNull BaseAdvancement> getAdvancementsWithoutRoot() {
        checkInitialisation();
        if (advsWithoutRoot != null) {
            return advsWithoutRoot;
        } else {
            List<BaseAdvancement> list = new ArrayList<>(advancements.size());
            for (Advancement a : advancements.values()) {
                if (a instanceof BaseAdvancement base) {
                    list.add(base);
                }
            }
            return advsWithoutRoot = Collections.unmodifiableList(list);
        }
    }

    /**
     * Gets an unmodifiable {@link Collection} of all the tab's advancements
     * that are an instance of the provided class or any of its subclasses.
     * <p>If the provided class is {@code null}, then an empty {@link Collection} is returned.
     *
     * @param filterClass The filter class.
     * @return An unmodifiable {@link Collection} of all the tab's advancements
     *     that are an instance of the provided class or any of its subclasses.
     * @throws IllegalStateException If the tab is not initialised.
     * @throws DisposedException If the tab is disposed.
     */
    @Unmodifiable
    @NotNull
    @Contract(pure = true)
    public Collection<@NotNull Advancement> getAdvancementsByClass(Class<? extends Advancement> filterClass) {
        checkInitialisation();
        if (filterClass == null) {
            return Collections.emptyList();
        }
        if (filterClass == Advancement.class) {
            return Collections.unmodifiableCollection(advancements.values());
        }
        if (rootAdvancement.getClass().isInstance(filterClass)) {
            return Collections.singletonList(rootAdvancement);
        }
        if (filterClass.isInstance(BaseAdvancement.class)) {
            Collection<Advancement> coll = new ArrayList<>(advancements.size());
            for (Advancement a : advancements.values()) {
                if (a.getClass().isInstance(filterClass)) {
                    coll.add(a);
                }
            }
            return Collections.unmodifiableCollection(coll);
        }
        return Collections.emptyList();
    }

    /**
     * Gets an unmodifiable {@link Set} of the {@link AdvancementKey}s of all the tab's advancements.
     *
     * @return An unmodifiable {@link Set} of the {@link AdvancementKey}s of all the tab's advancements.
     * @throws IllegalStateException If the tab is not initialised.
     * @throws DisposedException If the tab is disposed.
     */
    @UnmodifiableView
    @NotNull
    @Contract(pure = true)
    public Set<@NotNull AdvancementKey> getAdvancementsNamespacedKeys() {
        checkInitialisation();
        return Collections.unmodifiableSet(advancements.keySet());
    }

    /**
     * Returns whether the provided advancement belongs to the tab.
     *
     * @param advancement The advancement.
     * @return Whether the provided advancement belongs to the tab.
     * @throws IllegalStateException If the tab is not initialised.
     * @throws DisposedException If the tab is disposed.
     */
    @Contract(pure = true, value = "null -> false")
    public boolean hasAdvancement(Advancement advancement) {
        checkInitialisation();
        if (advancement == null)
            return false;
        return advancements.containsKey(advancement.getKey());
    }

    /**
     * Returns whether an advancement with the provided {@link AdvancementKey} belongs to the tab.
     *
     * @param namespacedKey The {@link AdvancementKey} of the advancement.
     * @return Whether an advancement with the provided {@link AdvancementKey} belongs to the tab.
     * @throws IllegalStateException If the tab is not initialised.
     * @throws DisposedException If the tab is disposed.
     */
    @Contract(pure = true, value = "null -> false")
    public boolean hasAdvancement(AdvancementKey namespacedKey) {
        checkInitialisation();
        return advancements.containsKey(namespacedKey);
    }

    /**
     * Gets the advancement of the tab with the provided {@link AdvancementKey}.
     *
     * @param namespacedKey The {@link AdvancementKey} of the wanted advancement of this tab.
     * @return The advancement of the tab with the provided {@link AdvancementKey}, or {@code null} if there's not.
     * @throws IllegalStateException If the tab is not initialised.
     * @throws DisposedException If the tab is disposed.
     */
    @Nullable
    @Contract(pure = true, value = "null -> null")
    public Advancement getAdvancement(AdvancementKey namespacedKey) {
        checkInitialisation();
        return advancements.get(namespacedKey);
    }

    /**
     * Returns an unmodifiable {@link Set} of the players the tab is currently shown to.
     *
     * @return An unmodifiable {@link Set} of the players the tab is currently shown to.
     * @throws IllegalStateException If the tab is not initialised.
     * @throws DisposedException If the tab is disposed.
     */
    @UnmodifiableView
    @NotNull
    @Contract(pure = true)
    public Set<@NotNull Player> getPlayers() {
        checkInitialisation();
        return Collections.unmodifiableSet(players.keySet());
    }

    /**
     * Grants the root advancement of the tab to the specified player giving rewards.
     *
     * @param player The player who is completing the root advancement.
     * @throws IllegalStateException If the tab is not initialised.
     * @throws DisposedException If the tab is disposed.
     */
    public void grantRootAdvancement(@NotNull Player player) {
        checkInitialisation();
        rootAdvancement.setProgression(player, rootAdvancement.getMaxProgression());
    }

    /**
     * Grants the root advancement of the tab to the specified player giving rewards.
     *
     * @param uuid The {@link UUID} of the player who is completing the root advancement.
     * @throws IllegalStateException If the tab is not initialised.
     * @throws DisposedException If the tab is disposed.
     */
    public void grantRootAdvancement(@NotNull UUID uuid) {
        checkInitialisation();
        rootAdvancement.setProgression(uuid, rootAdvancement.getMaxProgression());
    }

    /**
     * Grants the root advancement of the tab to the specified player.
     *
     * @param player The player who is completing the root advancement.
     * @param giveRewards Whether to give rewards.
     * @throws IllegalStateException If the tab is not initialised.
     * @throws DisposedException If the tab is disposed.
     */
    public void grantRootAdvancement(@NotNull Player player, boolean giveRewards) {
        checkInitialisation();
        rootAdvancement.setProgression(player, rootAdvancement.getMaxProgression(), giveRewards);
    }

    /**
     * Grants the root advancement of the tab to the specified player.
     *
     * @param uuid The {@link UUID} of the player who is completing the root advancement.
     * @param giveRewards Whether to give rewards.
     * @throws IllegalStateException If the tab is not initialised.
     * @throws DisposedException If the tab is disposed.
     */
    public void grantRootAdvancement(@NotNull UUID uuid, boolean giveRewards) {
        checkInitialisation();
        rootAdvancement.setProgression(uuid, rootAdvancement.getMaxProgression(), giveRewards);
    }

    /**
     * Sends or updates the advancements of the tab to the provided player's team members.
     *
     * @param player The player.
     * @throws IllegalStateException If the tab is not initialised.
     * @throws DisposedException If the tab is disposed.
     * @throws UserNotLoadedException If the provided player's team is not loaded.
     */
    public void updateAdvancementsToTeam(@NotNull Player player) throws UserNotLoadedException {
        updateAdvancementsToTeam(AdvancementUtils.uuidFromPlayer(player));
    }

    /**
     * Sends or updates the advancements of the tab to the provided player's team members.
     *
     * @param uuid A {@link UUID} of the player.
     * @throws IllegalStateException If the tab is not initialised.
     * @throws DisposedException If the tab is disposed.
     * @throws UserNotLoadedException If the provided player's team is not loaded.
     */
    public void updateAdvancementsToTeam(@NotNull UUID uuid) throws UserNotLoadedException {
        updateAdvancementsToTeam(databaseManager.getTeamProgression(uuid));
    }

    /**
     * Sends or updates the advancements of the tab to the provided team's members.
     *
     * @param pro The {@link TeamProgression} of the team.
     * @throws IllegalStateException If the tab is not initialised.
     * @throws DisposedException If the tab is disposed.
     */
    public void updateAdvancementsToTeam(@NotNull TeamProgression pro) {
        checkInitialisation();
        validateTeamProgression(pro);
        updateManager.schedule(pro);
    }

    /**
     * Sends or updates the advancements of the tab to the provided player.
     *
     * @param player The player.
     * @throws IllegalStateException If the tab is not initialised.
     * @throws DisposedException If the tab is disposed.
     * @throws UserNotLoadedException If the provided player's team is not loaded.
     * @deprecated Use {@link #updateAdvancementsToTeam(Player)} instead.
     */
    @Deprecated(since = "2.2.0")
    public void updateEveryAdvancement(@NotNull Player player) throws UserNotLoadedException {
        updateAdvancementsToTeam(player);
    }

    /**
     * Register the advancements for this tab, initializing the tab. Thus, it cannot be called twice.
     *
     * @param rootAdvancement The root of this tab.
     * @param advancements The advancements of this tab. Cannot include any {@code null} advancement or {@link RootAdvancement}.
     * @throws IllegalStateException If the tab is already initialised.
     * @throws DisposedException If the tab is disposed.
     */
    public void registerAdvancements(@NotNull RootAdvancement rootAdvancement, @NotNull BaseAdvancement... advancements) {
        registerAdvancements(rootAdvancement, Sets.newHashSet(advancements));
    }

    /**
     * Register the advancements for this tab, initializing the tab. Thus, it cannot be called twice.
     *
     * @param rootAdvancement The root of this tab.
     * @param advancements The advancements of this tab. Cannot include any {@code null} advancement or {@link RootAdvancement}.
     * @throws IllegalStateException If the tab is already initialised.
     * @throws DisposedException If the tab is disposed.
     */
    public void registerAdvancements(@NotNull RootAdvancement rootAdvancement, @NotNull Set<BaseAdvancement> advancements) {
        registerAdvancements(rootAdvancement, advancements, false);
    }

    /** Applies automatic layout before registration when requested. */
    public void registerAdvancements(RootAdvancement root, boolean automaticLayout, BaseAdvancement... advancements) {
        registerAdvancements(root, Sets.newHashSet(advancements), automaticLayout);
    }

    public void registerAdvancements(RootAdvancement rootAdvancement, Set<BaseAdvancement> advancements, boolean automaticLayout) {
        if (disposed) {
            throw new DisposedException("AdvancementTab is disposed.");
        }
        if (initialised)
            throw new IllegalStateException("Tab is already initialised.");
        Preconditions.checkNotNull(rootAdvancement, "RootAdvancement is null.");
        Preconditions.checkArgument(isOwnedByThisTab(rootAdvancement), "RootAdvancement " + rootAdvancement + " is not owned by this tab.");

        for (BaseAdvancement a : advancements) {
            if (a == null) {
                throw new IllegalArgumentException("An advancement is null.");
            }
            if (!isOwnedByThisTab(a)) {
                throw new IllegalArgumentException("Advancement " + a.getKey().toString() + " is not owned by this tab.");
            }
        }

        if (automaticLayout) com.fren_gor.ultimateAdvancementAPI.util.AdvancementLayout.applyVanilla(rootAdvancement, advancements);

        // Just to be sure
        this.advancements.clear();

        this.rootAdvancement = rootAdvancement;
        this.advancements.put(rootAdvancement.getKey(), rootAdvancement);

        final PluginManager pluginManager = Bukkit.getPluginManager();

        callOnRegister(rootAdvancement);

        try {
            pluginManager.callEvent(new AdvancementRegistrationEvent(rootAdvancement));
        } catch (IllegalStateException e) {
            onRegisterFail();
            throw e;
        }

        for (BaseAdvancement adv : advancements) {
            if (this.advancements.put(adv.getKey(), adv) != null) {
                onRegisterFail();
                throw new DuplicatedException("Advancement " + adv.getKey() + " is duplicated.");
            }

            callOnRegister(adv);

            try {
                pluginManager.callEvent(new AdvancementRegistrationEvent(adv));
            } catch (IllegalStateException e) {
                onRegisterFail();
                throw e;
            }
        }

        // Initialise before validation since advancementTab's methods have to be called
        // Make sure to revert it in case of an invalid advancement is found. See onRegisterFail()
        initialised = true;

        for (Advancement adv : this.advancements.values()) {
            callValidation(adv);
        }
    }

    private void callOnRegister(Advancement adv) {
        try {
            adv.onRegister();
        } catch (Exception e) {
            onRegisterFail();
            throw new RuntimeException("Exception occurred while registering advancement " + adv.getKey() + ':', e);
        }
    }

    private void callValidation(Advancement adv) {
        try {
            adv.validateRegister();
        } catch (InvalidAdvancementException e) {
            onRegisterFail();
            throw new RuntimeException("Advancement " + adv.getKey() + " is not valid:", e);
        } catch (Exception e) {
            onRegisterFail();
            throw new RuntimeException("Exception occurred while validating advancement " + adv.getKey() + ':', e);
        }
    }

    private void onRegisterFail() {
        // Revert initialised to false in case of an invalid advancement is found
        initialised = false;
        advancements.clear();
        rootAdvancement = null;
    }

    /**
     * Shows the tab to the provided players and sends them the advancements of the tab.
     *
     * @param players The players the tab will be shown to.
     * @throws IllegalStateException If the tab is not initialised.
     * @throws DisposedException If the tab is disposed.
     */
    public void showTab(@NotNull Player... players) {
        checkInitialisation();
        Preconditions.checkNotNull(players, "Player[] is null.");
        for (Player p : players) {
            try {
                showTab(p);
            } catch (Exception e) {
                // Add other players anyway
                e.printStackTrace();
            }
        }
    }

    /**
     * Shows the tab to the provided player and sends them the advancements of the tab.
     *
     * @param player The player the tab will be shown to.
     * @throws IllegalStateException If the tab is not initialised.
     * @throws DisposedException If the tab is disposed.
     */
    public void showTab(@NotNull Player player) {
        checkInitialisation();
        Preconditions.checkNotNull(player, "Player is null.");
        if (!players.containsKey(player)) {
            TeamProgression team = databaseManager.getTeamProgression(AdvancementUtils.uuidFromPlayer(player));
            if (players.putIfAbsent(player, ClientState.empty(clientGeneration.get())) == null) {
                updateAdvancementsToTeam(team);
            }
        }
    }

    /**
     * Hides the tab and its advancements to the provided players.
     *
     * @param players The players the tab will be hid to.
     * @throws IllegalStateException If the tab is not initialised.
     * @throws DisposedException If the tab is disposed.
     * @since 1.0.2
     */
    public void hideTab(@NotNull Player... players) {
        checkInitialisation();
        Preconditions.checkNotNull(players, "Player[] is null.");
        for (Player p : players) {
            try {
                hideTab(p);
            } catch (Exception e) {
                // Remove other players anyway
                e.printStackTrace();
            }
        }
    }

    /**
     * Hides the tab and its advancements to the provided player.
     *
     * @param player The player the tab will be hid to.
     * @throws IllegalStateException If the tab is not initialised.
     * @throws DisposedException If the tab is disposed.
     */
    public void hideTab(@NotNull Player player) {
        checkInitialisation();
        Preconditions.checkNotNull(player, "Player is null.");

        long generation = clientGeneration.get();
        ClientKeys restored = updateManager.previousKeys.remove(player.getUniqueId());
        Set<MinecraftKeyWrapper> keys = new HashSet<>();
        if (restored != null && restored.generation == generation) keys.addAll(restored.keys);
        ClientState sent = players.remove(player);
        if (sent != null && sent.generation == generation) keys.addAll(sent.keys);
        removePlayer(player, keys);
    }

    private void removePlayer(@NotNull Player player, Set<MinecraftKeyWrapper> keys) {
        if (keys == null || keys.isEmpty())
            return;
        try {
            ISendable packet = PacketPlayOutAdvancementsWrapper.craftRemovePacket(keys);
            SchedulerSupport.player(databaseManager.getOwningPlugin(), player, 0, () -> packet.sendTo(player));
        } catch (ReflectiveOperationException e) {
            e.printStackTrace();
        }
    }

    void dispose() {
        dispose(true);
    }

    Map<UUID, Set<MinecraftKeyWrapper>> snapshotClientKeys() {
        long generation = clientGeneration.get();
        Map<UUID, Set<MinecraftKeyWrapper>> keys = new HashMap<>();
        updateManager.previousKeys.forEach((uuid, restored) -> { if (restored.generation == generation) keys.put(uuid, restored.keys); });
        players.forEach((player, sent) -> { if (sent.generation == generation && !sent.keys.isEmpty()) keys.put(player.getUniqueId(), sent.keys); });
        return keys;
    }

    void restoreClientKeys(Map<UUID, Set<MinecraftKeyWrapper>> keys) {
        long generation = clientGeneration.get();
        keys.forEach((uuid, sent) -> updateManager.previousKeys.put(uuid, new ClientKeys(generation, sent)));
    }

    /** Invalidates definitions and removal history without hiding the tab. */
    void resetClientAdvancements() {
        clientGeneration.incrementAndGet();
        updateManager.previousKeys.clear();
        for (Player player : players.keySet()) {
            try {
                updateAdvancementsToTeam(player.getUniqueId());
            } catch (UserNotLoadedException ignored) {
                // A later update retries while the client generation remains invalidated.
            }
        }
    }

    void dispose(boolean removeClient) {
        checkInitialisation();
        Map<UUID, Set<MinecraftKeyWrapper>> clientKeys = removeClient ? snapshotClientKeys() : Collections.emptyMap();
        disposed = true;
        eventManager.disable();
        updateManager.dispose();
        players.clear();
        clientKeys.forEach((uuid, keys) -> {
            Player player = Bukkit.getPlayer(uuid);
            if (player != null) removePlayer(player, keys);
        });
        PluginManager pluginManager = Bukkit.getPluginManager();
        for (Advancement a : advancements.values()) {
            try {
                // Trigger AdvancementDisposeEvent
                try {
                    pluginManager.callEvent(new AdvancementDisposeEvent(a));
                } catch (IllegalStateException e) {
                    System.err.println("An exception has occurred while calling AdvancementDisposeEvent for " + a);
                    e.printStackTrace();
                }
                // Dispose the advancement
                a.onDispose();
                // Trigger AdvancementDisposedEvent
                try {
                    pluginManager.callEvent(new AdvancementDisposedEvent(a.getKey()));
                } catch (IllegalStateException e) {
                    System.err.println("An exception has occurred while calling AdvancementDisposedEvent for " + a);
                    e.printStackTrace();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        advancements.clear();
        rootAdvancement = null;
        advNamespacedKeys = null;
        advsWithoutRoot = null;
    }

    /**
     * Returns whether the tab is shown to the specified player.
     *
     * @param player The player.
     * @return Whether the tab is shown to the specified player.
     * @throws IllegalStateException If the tab is not initialised.
     * @throws DisposedException If the tab is disposed.
     */
    @Contract(pure = true, value = "null -> false")
    public boolean isShownTo(Player player) {
        checkInitialisation();
        return players.containsKey(player);
    }

    /**
     * Returns an unmodifiable {@link Collection} of all the advancement's keys of this tab as {@link String}s.
     *
     * @return An unmodifiable {@link Collection} of all the advancement's keys of this tab as {@link String}s.
     * @throws IllegalStateException If the tab is not initialised.
     * @throws DisposedException If the tab is disposed.
     */
    @Unmodifiable
    @NotNull
    public Collection<@NotNull String> getAdvancementsAsStrings() {
        checkInitialisation();
        if (advNamespacedKeys != null) {
            return advNamespacedKeys;
        } else {
            List<String> list = new ArrayList<>(advancements.size());
            for (AdvancementKey key : advancements.keySet()) {
                list.add(key.toString());
            }
            return advNamespacedKeys = Collections.unmodifiableCollection(list);
        }
    }

    /**
     * Returns whether the namespace of the specified advancement's key is equals to this tab namespace.
     *
     * @param advancement The advancement.
     * @return Whether the namespace of the specified advancement's key is equals to this tab namespace.
     */
    @Contract(pure = true)
    public boolean isOwnedByThisTab(@NotNull Advancement advancement) {
        Preconditions.checkNotNull(advancement, "Advancement is null.");
        return advancement.getKey().getNamespace().equals(namespace);
    }

    /**
     * Utility method which automatically shows this tab to every player just after they have been loaded.
     * <p>More formally, this is equivalent to calling:
     * <blockquote><pre>
     * tab.registerEvent(PlayerLoadingCompletedEvent.class, EventPriority.LOWEST, e -> tab.showTab(e.getPlayer()));
     * </pre></blockquote>
     *
     * @return This {@code AdvancementTab}.
     * @throws IllegalStateException If the tab is not initialised.
     * @throws DisposedException If the tab is disposed.
     * @since 2.2.0
     */
    @NotNull
    @Contract("-> this")
    public AdvancementTab automaticallyShowToPlayers() {
        checkInitialisation();
        if (!automaticallyShown) {
            automaticallyShown = true;
            // Use LOWEST priority in order to show the tab as soon as possible
            registerEvent(PlayerLoadingCompletedEvent.class, EventPriority.LOWEST, e -> showTab(e.getPlayer()));
        }
        return this;
    }

    /**
     * Utility method which automatically grants the root advancement of this tab to every player after they have been loaded.
     * <p>More formally, this is equivalent to calling:
     * <blockquote><pre>
     * tab.registerEvent(PlayerLoadingCompletedEvent.class, EventPriority.LOW, e -> tab.grantRootAdvancement(e.getPlayer()));
     * </pre></blockquote>
     *
     * @return This {@code AdvancementTab}.
     * @throws IllegalStateException If the tab is not initialised.
     * @throws DisposedException If the tab is disposed.
     * @since 2.2.0
     */
    @NotNull
    @Contract("-> this")
    public AdvancementTab automaticallyGrantRootAdvancement() {
        checkInitialisation();
        if (!automaticallyGrant) {
            automaticallyGrant = true;
            // Use LOW priority since automaticallyShowToPlayers() uses LOWEST priority
            registerEvent(PlayerLoadingCompletedEvent.class, EventPriority.LOW, e -> grantRootAdvancement(e.getPlayer()));
        }
        return this;
    }

    /**
     * Registers the provided event into the {@link EventManager} of this tab.
     *
     * @param eventClass The class of the event to register.
     * @param consumer The code to run when the event occurs.
     * @param <E> The class of the event to register.
     * @throws DisposedException If the tab is disposed.
     * @throws IllegalArgumentException If any argument is null.
     * @since 2.2.0
     */
    public <E extends Event> void registerEvent(@NotNull Class<E> eventClass, @NotNull Consumer<E> consumer) {
        try {
            eventManager.register(this, eventClass, consumer);
        } catch (IllegalStateException e) {
            throw new DisposedException(e);
        }
    }

    /**
     * Registers the provided event into the {@link EventManager} of this tab.
     *
     * @param eventClass The class of the event to register.
     * @param priority The priority of the event. See {@link EventPriority}.
     * @param consumer The code to run when the event occurs.
     * @param <E> The class of the event to register.
     * @throws DisposedException If the tab is disposed.
     * @throws IllegalArgumentException If any argument is null.
     * @since 2.2.0
     */
    public <E extends Event> void registerEvent(@NotNull Class<E> eventClass, @NotNull EventPriority priority, @NotNull Consumer<E> consumer) {
        try {
            eventManager.register(this, eventClass, priority, consumer);
        } catch (IllegalStateException e) {
            throw new DisposedException(e);
        }
    }

    private void checkInitialisation() {
        if (disposed)
            throw new DisposedException("AdvancementTab is disposed");
        if (!initialised)
            throw new IllegalStateException("AdvancementTab has not been initialised yet.");
    }

    /**
     * Returns the namespace of the tab.
     *
     * @return The namespace of the tab.
     */
    @NotNull
    @Override
    public String toString() {
        return namespace;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        AdvancementTab that = (AdvancementTab) o;

        return namespace.equals(that.namespace);
    }

    @Override
    public int hashCode() {
        return namespace.hashCode();
    }

    /**
     * Gets the plugin that created this advancement tab.
     *
     * @return The plugin that created this advancement tab.
     */
    @NotNull
    public Plugin getOwningPlugin() {
        return owningPlugin;
    }

    /**
     * Gets the {@link EventManager} of this tab.
     *
     * @return The {@link EventManager} of this tab.
     */
    @NotNull
    public EventManager getEventManager() {
        return eventManager;
    }

    /**
     * Gets the unique namespace of this tab.
     *
     * @return The unique namespace of this tab.
     */
    @NotNull
    public String getNamespace() {
        return namespace;
    }

    /**
     * Gets the {@link DatabaseManager} of this tab.
     *
     * @return The {@link DatabaseManager} of this tab.
     */
    @NotNull
    public DatabaseManager getDatabaseManager() {
        return databaseManager;
    }

    /**
     * Gets whether the tab is initialized.
     *
     * @return Whether the tab is initialized.
     */
    public boolean isInitialised() {
        return initialised;
    }

    /**
     * Returns whether the tab is disposed.
     *
     * @return Whether the tab is disposed.
     */
    public boolean isDisposed() {
        return disposed;
    }

    /** Discards the client snapshot and resends definitions on the player's owning thread. */
    public void forceUpdateAdvancements(Player player) {
        checkInitialisation();
        SchedulerSupport.player(owningPlugin, player, 0, () -> {
            if (disposed) return;
            TeamProgression team = databaseManager.getTeamProgression(player);
            players.compute(player, (ignored, previous) -> previous == null ? ClientState.empty(clientGeneration.get())
                    : new ClientState(previous.generation, Collections.emptyMap(), previous.keys));
            updateManager.schedule(team);
        });
    }

    private class AdvsUpdateRunnable implements Runnable {

        private final Set<TeamProgression> advsToUpdate = ConcurrentHashMap.newKeySet();
        private final Set<Player> pendingPlayers = ConcurrentHashMap.newKeySet();
        private final Map<UUID, ClientKeys> previousKeys = new ConcurrentHashMap<>();
        private SchedulerSupport.Task task;
        private boolean scheduled;

        public synchronized void schedule(TeamProgression progression) {
            if (disposed) return;
            advsToUpdate.add(progression);
            if (!scheduled) {
                scheduled = true;
                task = SchedulerSupport.global(owningPlugin, 1, this);
            }
        }

        public synchronized void dispose() {
            if (task != null) task.cancel();
            advsToUpdate.clear();
            pendingPlayers.clear();
            previousKeys.clear();
            scheduled = false;
        }

        @Override
        public void run() {
            int budget = 16;
            for (TeamProgression team : advsToUpdate) {
                if (--budget < 0) break;
                advsToUpdate.remove(team);
                team.forEachMember(uuid -> {
                    Player player = Bukkit.getPlayer(uuid);
                    if (player == null || !pendingPlayers.add(player)) return;
                    SchedulerSupport.player(owningPlugin, player, 1, () -> {
                        pendingPlayers.remove(player);
                        if (!disposed && databaseManager.isLoaded(player.getUniqueId())) updatePlayer(player, databaseManager.getTeamProgression(player));
                    }, () -> { pendingPlayers.remove(player); players.remove(player); previousKeys.remove(uuid); });
                });
            }
            synchronized (this) {
                scheduled = false;
                task = null;
                if (!advsToUpdate.isEmpty()) {
                    scheduled = true;
                    task = SchedulerSupport.global(owningPlugin, 1, this);
                }
            }
        }

        private void updatePlayer(Player player, TeamProgression team) {
            ClientState state = players.get(player);
            if (state == null) return;
            long generation = clientGeneration.get();
            Map<AdvancementWrapper, Integer> current = new HashMap<>(advancements.size() + 16);
            for (Advancement advancement : advancements.values()) advancement.onUpdate(team, current);
            Map<AdvancementWrapper, Integer> previous = state.generation == generation ? state.progress : Collections.emptyMap();
            var delta = com.fren_gor.ultimateAdvancementAPI.util.ClientStateDelta.between(previous, current);
            Set<MinecraftKeyWrapper> removed = new HashSet<>();
            delta.removed().forEach(wrapper -> removed.add(wrapper.getKey()));
            ClientKeys restored = previousKeys.get(player.getUniqueId());
            Set<MinecraftKeyWrapper> keys = null;
            if ((restored != null && restored.generation == generation)
                    || (previous.isEmpty() && state.generation == generation && !state.keys.isEmpty())) {
                keys = new HashSet<>();
                for (AdvancementWrapper wrapper : current.keySet()) keys.add(wrapper.getKey());
                if (restored != null && restored.generation == generation) removed.addAll(restored.keys);
                if (state.generation == generation) removed.addAll(state.keys);
                removed.removeAll(keys);
            }
            if (generation != clientGeneration.get()) { schedule(team); return; }
            if (delta.isEmpty() && removed.isEmpty() && state.generation == generation) return;
            if (!delta.isEmpty() || !removed.isEmpty()) {
                try { PacketPlayOutAdvancementsWrapper.craftUpdatePacket(delta.added(), removed, delta.progress()).sendTo(player); }
                catch (ReflectiveOperationException error) { error.printStackTrace(); return; }
            }
            if (keys == null && delta.added().isEmpty() && delta.removed().isEmpty() && state.generation == generation) {
                keys = state.keys;
            } else if (keys == null) {
                keys = new HashSet<>();
                for (AdvancementWrapper wrapper : current.keySet()) keys.add(wrapper.getKey());
                keys = Set.copyOf(keys);
            } else keys = Set.copyOf(keys);
            players.replace(player, state, new ClientState(generation, Map.copyOf(current), keys));
            if (restored != null) previousKeys.remove(player.getUniqueId(), restored);
            if (generation != clientGeneration.get()) schedule(team);
        }
    }

    private record ClientKeys(long generation, Set<MinecraftKeyWrapper> keys) {}
    private record ClientState(long generation, Map<AdvancementWrapper, Integer> progress, Set<MinecraftKeyWrapper> keys) {
        private static ClientState empty(long generation) {
            return new ClientState(generation, Collections.emptyMap(), Collections.emptySet());
        }
    }
}
