rootProject.name = "FluidCoreConsumerVerification"
